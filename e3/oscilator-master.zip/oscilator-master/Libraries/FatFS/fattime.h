#ifndef FATTIME_H_
#define FATTIME_H_

#include "integer.h"

DWORD get_fattime (void);

#endif
