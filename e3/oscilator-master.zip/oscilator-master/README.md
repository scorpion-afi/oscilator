oscilator
=========
