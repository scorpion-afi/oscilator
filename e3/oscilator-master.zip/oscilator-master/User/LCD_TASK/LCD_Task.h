// LCDTask 

#ifdef	LCDTask
  #define GLB_LCDTask				
#else	
  #define GLB_LCDTask extern
#endif

  GLB_LCDTask void vLCDTask(void *pvParameters);

#ifdef LCDTask

#endif