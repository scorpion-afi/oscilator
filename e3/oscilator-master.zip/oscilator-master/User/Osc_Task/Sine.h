  
 void CalcSin(void);

