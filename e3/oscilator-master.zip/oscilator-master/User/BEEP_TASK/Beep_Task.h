// BeepTask 

#ifdef	BeepTask
  #define GLB_BeepTask 		
#else	
  #define GLB_BeepTask extern
#endif

  GLB_BeepTask void vBeepTask(void *pvParameters);
  
#ifdef	BeepTask

#endif
